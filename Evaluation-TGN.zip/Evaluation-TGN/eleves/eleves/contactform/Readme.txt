Fully working PHP/AJAX contact form is available in the pro version.
You can buy it from: https://bootstrapmade.com/enno-free-simple-bootstrap-template/
